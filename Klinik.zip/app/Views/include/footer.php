<footer class="border-top mt-4" style="width: 100%; padding: 2rem 0; flex-shrink: 0;">
	<div class="my-auto text-center">
		<small class="text-muted">&copy;<script>
				document.write(new Date().getFullYear());
			</script> All rights reserved to Diokta Redho & dr. Farabi El Fouz, Sp.A, M.kes</small>
	</div>
</footer>

<script>
	// Example starter JavaScript for disabling form submissions if there are invalid fields
	(function() {
		'use strict';
		window.addEventListener('load', function() {
			// Fetch all the forms we want to apply custom Bootstrap validation styles to
			var forms = document.getElementsByClassName('needs-validation');
			// Loop over them and prevent submission
			var validation = Array.prototype.filter.call(forms, function(form) {
				form.addEventListener('submit', function(event) {
					if (form.checkValidity() === false) {
						event.preventDefault();
						event.stopPropagation();
					}
					form.classList.add('was-validated');
				}, false);
			});
		}, false);
	})();
</script>
</body>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM" crossorigin="anonymous"></script>

<script src="<?= base_url('js/sweetalert2/sweetalert2.all.min.js'); ?>"></script>
<script src="<?= base_url('js/myscript.js'); ?>"></script>

</html>