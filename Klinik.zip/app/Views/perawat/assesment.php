<div class="container mt-1 ms-4 me-0 mw-100">
    <div class="row w-auto me-4">
        <div class="col-3 ps-0 bg-white me-2 p-2">
            <div class="list-group">
                <a href="<?= base_url('perawat/assesment/' . $pasien['id']) ?>" class="list-group-item list-group-item-action fw-bold" style="color: #E79E5A;">
                    <img src=" <?= base_url('images/Cardiograph-orange.png') ?>" class="img-thumbnail" style="height: 30px;" alt="">
                    Assessment Perawat
                </a>
            </div>
        </div>
        <div class="col ms-2">
            <div class="row py-3 bg-white">
                <div class="col-2">
                    <img src=" <?= base_url('images/profile.png') ?>" class="img-thumbnail border-0 p-0">
                </div>
                <div class="col ">
                    <h5><?= $pasien['nama']; ?></h5>
                    <h6><?php if ($pasien['jenisKelamin'] == 'L') {
                            echo 'Laki-laki';
                        } else {
                            echo 'Perempuan';
                        } ?></h6>
                    <h6><?= $pasien['tanggalLahir']; ?> - <?= $pasien['umur']; ?></h6>
                    <h6>No. Rekam Medis : <?= $pasien['id']; ?></h6>
                </div>
            </div>
            <div class="row pt-3 p-0 bg-white mt-3">
                <h5 class="font-weight-bold" style="color: B02525;">Keluhan Utama</h5>
            </div>
            <div class="row px-0 bg-white">
                <div class="col-100">
                    <hr style="color: #2269D2; height: 2px;">
                </div>
            </div>

            <form action="<?= base_url('perawat/insert_assesment/' . $pasien['id']) ?>" method="POST">
                <textarea class="form-control border-2" id="keluhanUtama" name="keluhanUtama" rows="2" required><?php if ($sameDay) {
                                                                                                                    echo $assesment['keluhanUtama'];
                                                                                                                } ?></textarea>
                <div class="row pt-3 p-0 bg-white mt-3">
                    <h5 class="font-weight-bold" style="color: B02525;">Assessment Perawat</h5>
                </div>
                <div class="row px-0 bg-white">
                    <div class="col-100">
                        <hr style="color: #2269D2; height: 2px;">
                    </div>
                </div>
                <div class="row bg-white justify-content-center py-1">
                    <div class="col-5" style="background-color: #E5E5E5;" align="center">
                        <h6 class="fw-bold" style="color: #2269D2;">Tanda Vital</h6>
                    </div>
                    <div class="col-5" style="background-color: #E5E5E5;" align="center">
                        <h6 class="fw-bold" style="color: #2269D2;">Nutrisi</h6>
                    </div>
                </div>
                <div class="row bg-white justify-content-center pt-2">
                    <div class="col-5">
                        <p class="fw-bold mb-0">Tekanan Darah</p>
                        <div class="row">
                            <div class="col">
                                <input type="text" class="form-control" name="tekananDarah" id="tekananDarah" autocomplete="off" required value="<?php if ($sameDay) {
                                                                                                                                                        echo $assesment['tekananDarah'];
                                                                                                                                                    } ?>">
                            </div>
                            <div class="col-2 px-0">
                                <p>MmHg</p>
                            </div>
                        </div>
                        <p class="fw-bold mb-0">Frekuensi Nadi</p>
                        <div class="row">
                            <div class="col">
                                <input type="text" class="form-control" name="frekuensiNadi" id="frekuensiNadi" autocomplete="off" required value="<?php if ($sameDay) {
                                                                                                                                                        echo $assesment['frekuensiNadi'];
                                                                                                                                                    } ?>">
                            </div>
                            <div class="col-2 px-0">
                                <p>X/Menit</p>
                            </div>
                        </div>
                        <p class="fw-bold mb-0">Suhu</p>
                        <div class="row">
                            <div class="col">
                                <input type="text" class="form-control" name="suhu" id="suhu" autocomplete="off" required value="<?php if ($sameDay) {
                                                                                                                                        echo $assesment['suhu'];
                                                                                                                                    } ?>">
                            </div>
                            <div class="col-2 px-0">
                                <p>C</p>
                            </div>
                        </div>
                        <p class="fw-bold mb-0">Frekuensi Nafas</p>
                        <div class="row">
                            <div class="col">
                                <input type="text" class="form-control" name="frekuensiNafas" id="frekuensiNafas" autocomplete="off" required value="<?php if ($sameDay) {
                                                                                                                                                            echo $assesment['frekuensiNafas'];
                                                                                                                                                        } ?>">
                            </div>
                            <div class="col-2 px-0">
                                <p>X/Menit</p>
                            </div>
                        </div>
                        <p class="fw-bold mb-0">Skor Nyeri</p>
                        <div class="row">
                            <div class="col">
                                <input type="text" class="form-control" name="skorNyeri" id="skorNyeri" autocomplete="off" required value="<?php if ($sameDay) {
                                                                                                                                                echo $assesment['skorNyeri'];
                                                                                                                                            } ?>">
                            </div>
                            <div class="col-2 px-0">
                            </div>
                        </div>
                    </div>
                    <div class="col-sm-1">
                    </div>
                    <div class=" col-5">
                        <p class="fw-bold mb-0">Berat Badan</p>
                        <div class="row">
                            <div class="col">
                                <input type="text" class="form-control" name="beratBadan" id="beratBadan" autocomplete="off" required value="<?php if ($sameDay) {
                                                                                                                                                    echo $assesment['beratBadan'];
                                                                                                                                                } ?>">
                            </div>
                            <div class="col-2 px-0">
                                <p>Kg</p>
                            </div>
                        </div>
                        <p class="fw-bold mb-0">Tinggi Badan</p>
                        <div class="row">
                            <div class="col">
                                <input type="text" class="form-control" name="tinggiBadan" id="tinggiBadan" autocomplete="off" required value="<?php if ($sameDay) {
                                                                                                                                                    echo $assesment['tinggiBadan'];
                                                                                                                                                } ?>">
                            </div>
                            <div class="col-2 px-0">
                                <p>Cm</p>
                            </div>
                        </div>
                        <!-- <p class="fw-bold mb-0">IMT</p>
                        <div class="row">
                            <div class="col">
                                <input type="text" class="form-control" name="imt" id="imt" autocomplete="off" required>
                            </div>
                            <div class="col-2 px-0">
                                <p>Kg/M2</p>
                            </div>
                        </div> -->
                        <!-- <p class="fw-bold mb-0">Khusus Pediatri</p>
                        <div class="row">
                            <div class="col">
                                <input type="text" class="form-control" name="pediatri" id="pediatri" autocomplete="off" required>
                            </div>
                            <div class="col-2 px-0">
                            </div>
                        </div> -->
                        <p class="fw-bold mb-0">Lingkar Kepala</p>
                        <div class="row">
                            <div class="col">
                                <input type="text" class="form-control" name="lingkarKepala" id="lingkarKepala" autocomplete="off" required value="<?php if ($sameDay) {
                                                                                                                                                        echo $assesment['lingkarKepala'];
                                                                                                                                                    } ?>">
                            </div>
                            <div class="col-2 px-0">
                                <p>Cm</p>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="row justify-content-center py-4 bg-white">
                    <div class="col text-center m-0">
                        <button type="submit" class="btn btn-primary text-center px-3 py-2" name="simpan">SIMPAN</button>
                    </div>
                </div>
            </form>
        </div>
    </div>
</div>